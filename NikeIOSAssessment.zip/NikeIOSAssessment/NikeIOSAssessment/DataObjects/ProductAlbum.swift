import Foundation
import UIKit

struct ProductAlbum {
    var artistName : String
    var albumName : String
    var albumImage : String?
}
